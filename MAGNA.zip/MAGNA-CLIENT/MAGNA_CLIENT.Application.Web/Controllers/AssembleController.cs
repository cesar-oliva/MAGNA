﻿using MAGNA_CLIENT.Abstractions;
using MAGNA_CLIENT.Application.Web.DataTransferObject;
using MAGNA_CLIENT.Application.Web.Service;
using MAGNA_CLIENT.Entities;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace MAGNA_CLIENT.Application.Web.Controllers
{
    public class AssembleController : Controller
    {
        const string nameService = "https://localhost:5001/";
        const string serviceGet = "api/Assemble";
        private readonly ICrudAsync<Assemble> con = new ServiceAssemble();

        //GET: Assemble
        public async Task<IActionResult> Index()
        {
            var assembleDTOList = await con.GetEntity(nameService, serviceGet);
            return View(assembleDTOList);
        }
        /*
        CREATE
       */
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(AssembleDTO assembleDTO)
        {
            //var request = await con.PostCreateEntity(nameService, serviceGet, assembleDTO);
            //if (request) return RedirectToAction("Index");
            return View();
        }
        /*
         UPDATE
        */
        [HttpGet]
        public async Task<IActionResult> Update(int? id)
        {
            var assemblyDTO = await con.GetUpdateEntity(nameService, serviceGet, id);
            return View(assemblyDTO);
        }
        [HttpPost]
        public async Task<IActionResult> Update(AssembleDTO assembleDTO)
        {
            //var request = await con.PutUpdateEntity(nameService, serviceGet, assembleDTO);
            //if (request) return RedirectToAction("Index");
            return View();
        }
        /*
         DELETE
        */
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var request = await con.GetDeleteEntity(nameService, serviceGet, id);
            if (request) return RedirectToAction("Index");
            return View();
        }
        /*
        DETAIL
        */
        [HttpGet]
        public async Task<IActionResult> Detail(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var asemmbleDTO = await con.GetDetailEntity(nameService, serviceGet, id);
            return View(asemmbleDTO);
        }
    }
}

