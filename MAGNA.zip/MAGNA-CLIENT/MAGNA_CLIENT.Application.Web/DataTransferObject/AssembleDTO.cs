﻿namespace MAGNA_CLIENT.Application.Web.DataTransferObject
{
    public class AssembleDTO
    {
        public string AssembleCode { get; set; }
        public string AssembleDescription { get; set; }
    }
}
