﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGNA_CLIENT.Entities
{
    public enum State
    {
        Activo = 0,
        Inactivo = 1,
    }
}
