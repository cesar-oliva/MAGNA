﻿using MAGNA_SERVER.DataAccess.Configurations;
using MAGNA_SERVER.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGNA_SERVER.DataAccess
{
    public class ApiDbContext : IdentityDbContext
    {
        public DbSet<Assemble> Assemble { get; set; }
        public DbSet<AssembleProperty> AssembleProperty { get; set; }
        public DbSet<AssembleInstance> AssembleInstance { get; set; }
        public DbSet<AssembleVersion> AssembleVersion { get; set; }
        public DbSet<AssembleType> AssembleType { get; set; }
        public DbSet<Employee> Employee { get; set; }
        public DbSet<Notice> Notice { get; set; }
        public DbSet<NoticePriority> NoticePriority { get; set; }
        public DbSet<NoticeState> NoticeState { get; set; }
        public DbSet<WorkOrder> WorkOrder { get; set; }
        public DbSet<WorkOrderState> WorkOrderState { get; set; }
        public DbSet<Gender> Gender { get; set; }


        public ApiDbContext(DbContextOptions<ApiDbContext> options): base(options)
        {


        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Ignore<Entity>();
            base.OnModelCreating(modelBuilder);
            //modelBuilder.ApplyConfiguration(new EmployeeConfigurations());
            //modelBuilder.ApplyConfiguration(new GenderConfigurations());

        }
    }
}
