﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGNA_SERVER.Entities
{
    [Table("Assemble")]
    public class Assemble : Entity
    {
        [Required]
        public string AssembleCode { get; set; }
        [Required]
        public string AssembleDescription { get; set; }

        /*Llave foranea assemble type*/
        public int AssembleTypeId { get; set; }
        [ForeignKey("AssembleTypeId")]
        public virtual  AssembleType AssembleType { get; set; }
        //tengo el id en la clase assemble version
        public virtual ICollection<AssembleVersion> AssembleVersions { get; set; } 
    }
}
