﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGNA_SERVER.Entities
{
    public class AssembleInstance : Entity
    {
        public String AssembleInstanceCode { get; set; }
        public String AssembleInstanceDescription { get; set; }
        public String AssembleInstanceLocation { get; set; }

        //llave foranea
        public int AssembleVersionId { get; set; }
        public virtual AssembleVersion AssembleVersion { get; set; }
        public virtual List<AssembleInstance> AssebleInstanceSubAssembles { get; set; }

    }
}
