﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGNA_SERVER.Entities
{
    public class AssembleProperty : Entity
    {
        public string AssemblePropertyDescription { get; set; }
        public string AssemblePropertyDetail { get; set; }
    }
}
