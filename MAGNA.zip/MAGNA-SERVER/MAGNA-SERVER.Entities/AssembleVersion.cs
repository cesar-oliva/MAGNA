﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGNA_SERVER.Entities
{
    public class AssembleVersion : Entity
    {
        public int AssembleVersionNumber { get; set; }
        public string AssembleVersionCode { get; set; }
        public string AssembleVersionDescription { get; set; }

        public virtual ICollection<AssembleProperty> AssembleProperty { get; set; } 
    }
}
