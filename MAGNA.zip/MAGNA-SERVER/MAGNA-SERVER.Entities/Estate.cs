﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGNA_SERVER.Entities
{
    public class Estate : Entity
    { 
        public string EstateDescription { get; set; }
    }
}
