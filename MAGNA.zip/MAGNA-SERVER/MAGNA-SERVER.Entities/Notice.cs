﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGNA_SERVER.Entities
{
    public class Notice : Entity
    {
        public string NoticeCode { get; set; }
        public string NoticeDescription { get; set; }
        public DateTime NoticeDate { get; set; }

        //llave foranea
        public int NoticeStateId { get; set; }
        public int NoticePriorityId { get; set; }
        public int AssembleInstanceId { get; set; }
        public virtual NoticeState NoticeState { get; set; }
        public virtual NoticePriority NoticePriority { get; set; }
        public virtual AssembleInstance AssembleInstance { get; set; }
    }
}
