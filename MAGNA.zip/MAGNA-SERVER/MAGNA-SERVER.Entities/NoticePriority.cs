﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGNA_SERVER.Entities
{
    public class NoticePriority : Entity
    {
        public string NoticePriorityDescription { get; set; }
    }
}
