﻿using MAGNA_SERVER.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGNA_SERVER.Repository
{
    public interface IRepository<T>:ICrud<T> 
    {

    }

    public class Repository<T> : IRepository<T> where T : IEntity
    {
        IDbContext<T> _dbc;
        public Repository(IDbContext<T> dbc)
        {
            _dbc = dbc;
        }

        public void Delete(int id)
        {
            _dbc.Delete(id);
        }
        public void DeleteAsync(int id)
        {
            _dbc.DeleteAsync(id);
        }

        public IList<T> GetAll()
        {
            return _dbc.GetAll();
        }
        public async Task<IList<T>> GetAllAsync()
        {
            return await _dbc.GetAllAsync();
        }
        public T GetById(int id)
        {
            return _dbc.GetById(id);
        }
        public async Task<T> GetByIdAsync(int id)
        {
            return await _dbc.GetByIdAsync(id);
        }
        public T Save(T entity)
        {
            return _dbc.Save(entity);   
        }
        public Task<T> SaveAsync(T entity)
        {
            return _dbc.SaveAsync(entity);
        }
    }
}
