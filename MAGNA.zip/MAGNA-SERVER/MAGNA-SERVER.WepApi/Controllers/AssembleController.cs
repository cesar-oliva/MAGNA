﻿using MAGNA_SERVER.Application;
using MAGNA_SERVER.Entities;
using MAGNA_SERVER.WebApi.DataTransferObject;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace MAGNA_SERVER.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssembleController : ControllerBase
    {
        IApplication<Assemble> _assemble;
        public AssembleController(IApplication<Assemble> assemble)
        {
            _assemble = assemble;
        }

        /*
         SAVE
        */
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            return Ok(await _assemble.GetAllAsync());
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> GetOne(int id)
        {
            if (id == 0) return NotFound();
            var assemble = await _assemble.GetByIdAsync(id);
            return Ok(assemble);
        }
        [HttpPost]
        public async Task<IActionResult> Save(AssembleDTO dto) //Mapear
        {
            var a = new Assemble()
            {
                AssembleCode = dto.AssembleCode,
                AssembleDescription = dto.AssembleDescription,
            };
            await _assemble.SaveAsync(a);
            return Ok(a);
        }
        /*
        UPDATE
        */
        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> Update(int id, AssembleDTO dto)
        {
            if (id == 0 || dto == null) return NotFound();
            var a = _assemble.GetById(id);
            if (a != null)
            {
                a.AssembleCode = dto.AssembleCode;
                a.AssembleDescription = dto.AssembleDescription;
            }
            await _assemble.SaveAsync(a);
            return Ok(a);
        }
        /*
        DELETE
        */
        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete(int id)
        {
            if (id == 0) return NotFound();
            _assemble.DeleteAsync(id);
            return Ok();
        }

    }
}
