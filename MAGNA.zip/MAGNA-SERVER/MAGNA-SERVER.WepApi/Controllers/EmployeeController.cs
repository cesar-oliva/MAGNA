﻿using AutoMapper;
using MAGNA_SERVER.Application;
using MAGNA_SERVER.Entities;
using MAGNA_SERVER.WebApi.DataTransferObject;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MAGNA_SERVER.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : Controller
    {
        IApplication<Employee> _employee;
        private readonly IMapper _mapper;
        public EmployeeController(IApplication<Employee> employee,IMapper mapper)
        {
            _employee = employee;
            _mapper = mapper;
        }
        /*
         SAVE
        */
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            List<EmployeeDTO> employeeDTO = new();
            var employee = await _employee.GetAllAsync();
     
            foreach (var item in employee)
            {
               employeeDTO.Add( _mapper.Map<EmployeeDTO>(item));
            }

            return Ok(employeeDTO);
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> GetOne(int id)
        {
            if (id == 0) return NotFound();
            var employee = await _employee.GetByIdAsync(id);
            return Ok(employee);
        }
        [HttpPost]
        public async Task<IActionResult> Save(EmployeeDTO employeeDto) 
        {
            Employee employee = _mapper.Map<Employee>(employeeDto); 
            await _employee.SaveAsync(employee);
            return Ok(employee);
        }
        /*
        UPDATE
        */
        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> Update(int id, EmployeeDTO dto)
        {
            Employee employee = new();
            if (id == 0 || dto == null) return NotFound();
            var employeeId = _employee.GetById(id);
            if (employeeId != null)
            {
                employee = _mapper.Map<Employee>(employeeId);
            }
            await _employee.SaveAsync(employee);
            return Ok(employee);
        }
        /*
        DELETE
        */
        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete(int id)
        {
            if (id == 0) return NotFound();
            _employee.DeleteAsync(id);
            return Ok();
        }
    }
}
