﻿namespace MAGNA_SERVER.WebApi.DataTransferObject
{
    public class AssembleDTO
    {
        public string AssembleCode { get; set; }
        public string AssembleDescription { get; set; }
    }
}
