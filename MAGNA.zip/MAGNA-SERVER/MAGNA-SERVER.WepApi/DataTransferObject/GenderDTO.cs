﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MAGNA_SERVER.WebApi.DataTransferObject
{
    public class GenderDTO
    {
        [Required]
        [Key]
        public int GenderId { get; set; }
        [StringLength(50)]
        public string GenderDescription { get; set; }
        [Required]
        [StringLength(50)]
        public bool GenderState { get; set; }

        public List<EmployeeDTO> EmployeeDTO { get; set; }
    }
}
